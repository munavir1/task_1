from django.contrib import admin
from my_work.models import *

# Register your models here.

admin.site.register(Attendancedb)
admin.site.register(DailyUpdateModel)
admin.site.register(DailyTaskModel)
